#!/usr/bin/env bash
# Compiles the regex engine to WebAssembly and places the output in docs/,
# ready to be served by GitHub Pages.
#
# Prerequisites: emsdk installed and activated (source emsdk_env.sh first).

set -e

emcc AutomataManager.cpp Parser.cpp wasm_bindings.cpp \
    -o docs/regex_engine.js \
    -s EXPORTED_FUNCTIONS='["_matchRegex","_getLastError"]' \
    -s EXPORTED_RUNTIME_METHODS='["ccall","cwrap"]' \
    -s ALLOW_MEMORY_GROWTH=1 \
    -s MODULARIZE=1 \
    -s EXPORT_NAME='RegexModule' \
    -O2

echo "Build complete. Output written to docs/regex_engine.js and docs/regex_engine.wasm"
echo "Test locally with:  cd docs && python3 -m http.server 8000"
echo "Then open http://localhost:8000"
