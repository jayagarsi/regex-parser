#include <emscripten/emscripten.h>
#include "Parser.hh"
#include "AutomataManager.hh"
#include <string>
#include <cstring>

// Simple static buffer used to hand error messages back to JS.
static std::string g_lastError;

extern "C" {

// Returns: 1 = match, 0 = no match, -1 = parse/runtime error.
// On -1, call getLastError() from JS to retrieve the error message.
EMSCRIPTEN_KEEPALIVE
int matchRegex(const char* pattern, const char* input) {
    try {
        std::string patternStr(pattern);
        Parser parser(patternStr);
        NodePtr ast = parser.parse();

        AutomataManager mgr;
        NFA nfa = mgr.regexToNFA(ast);

        std::string inputStr(input);
        bool result = mgr.isMatch(nfa, inputStr);

        g_lastError.clear();
        return result ? 1 : 0;
    } catch (const std::exception& e) {
        g_lastError = e.what();
        return -1;
    } catch (...) {
        g_lastError = "Unknown error while matching";
        return -1;
    }
}

// Returns a pointer to a null-terminated string with the last error message.
// Valid until the next call to matchRegex.
EMSCRIPTEN_KEEPALIVE
const char* getLastError() {
    return g_lastError.c_str();
}

}
